"""Create unpublished source/native bundles with exact inventories; no installers."""
import argparse
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
binary = args.binary.resolve()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)

def digest(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()

def archive(path, files, prefix):
    with path.open("xb") as destination:
        with tarfile.open(fileobj=destination, mode="w:gz", format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(files.items()):
                entry = tarfile.TarInfo(f"{prefix}/{name}")
                entry.size = len(data)
                entry.mode = 0o755 if name.startswith("bin/") else 0o644
                entry.mtime = 0
                tar.addfile(entry, io.BytesIO(data))

source = {}
for directory in ["crates", "fixtures", "relation-packs", "schemas", "sdk", "adapters", "scripts"]:
    for path in sorted((ROOT / directory).rglob("*")):
        if path.is_file() and not any(p in {"__pycache__", "node_modules", ".DS_Store"} for p in path.parts):
            source[path.relative_to(ROOT).as_posix()] = path.read_bytes()
for name in ["Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "LICENSE", "NOTICE", "README.md", "BUILD_PLAN.md", "docs/SPEC.md"]:
    source[name] = (ROOT / name).read_bytes()
for path in (ROOT / "docs/decisions").glob("*.md"):
    source[path.relative_to(ROOT).as_posix()] = path.read_bytes()
inventory = [{"path": name, "digest": digest(data), "bytes": len(data)} for name, data in sorted(source.items())]
source["source-inventory.json"] = (json.dumps(inventory, indent=2) + "\n").encode()
engine = json.loads(subprocess.check_output([str(binary), "engine"]))
rustc = str(Path.home() / ".cargo/bin/rustc")
toolchain = subprocess.check_output([rustc, "-vV"], text=True)
target = next(line.removeprefix("host: ") for line in toolchain.splitlines() if line.startswith("host: "))
receipt = {"schemaVersion": "0.1.0", "status": "unpublished-draft", "target": target,
           "toolchain": toolchain, "engines": engine, "binaryDigest": digest(binary.read_bytes()),
           "buildProfile": "caller-supplied; package hashing does not attest build provenance",
           "sourceInventoryDigest": digest(source["source-inventory.json"]),
           "protectedActivationAcceptance": "pending-linux-runtime"}
prefix = f"bindloom-draft-{engine['compiler'][7:19]}"
source_path = output / f"{prefix}-source.tar.gz"
binary_path = output / f"{prefix}-{target}.tar.gz"
archive(source_path, source, prefix)
native = {"bin/bindloom": binary.read_bytes(), "LICENSE": source["LICENSE"], "NOTICE": source["NOTICE"],
          "distribution.json": (json.dumps(receipt, indent=2) + "\n").encode()}
archive(binary_path, native, prefix)
receipt["sourceArchive"] = {"path": source_path.name, "digest": digest(source_path.read_bytes())}
receipt["nativeArchive"] = {"path": binary_path.name, "digest": digest(binary_path.read_bytes())}
(output / "distribution.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
