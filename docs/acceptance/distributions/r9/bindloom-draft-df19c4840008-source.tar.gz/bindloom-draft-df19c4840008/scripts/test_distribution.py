"""Install the actual bundle in a disposable directory outside this checkout."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("distribution", type=Path)
parser.add_argument("--node", type=Path, required=True)
parser.add_argument("--tsc", type=Path, required=True)
parser.add_argument("--reference", type=Path, required=True)
args = parser.parse_args()
receipt = json.loads((args.distribution / "distribution.json").read_text())
tools = Path.home() / ".cargo/bin"
env = {**os.environ, "CARGO_INCREMENTAL": "0", "CARGO_PROFILE_DEV_DEBUG": "0", "CARGO_PROFILE_TEST_DEBUG": "0"}

def run(argv, cwd, expected=0, env=env):
    result = subprocess.run([str(a) for a in argv], cwd=cwd, env=env, text=True, capture_output=True)
    assert result.returncode == expected, f"{argv}\n{result.returncode}\n{result.stdout}\n{result.stderr}"
    return result.stdout

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

with tempfile.TemporaryDirectory(prefix="bindloom-install-") as temporary:
    work = Path(temporary)
    with tarfile.open(args.distribution / receipt["sourceArchive"]["path"]) as archive:
        archive.extractall(work, filter="data")
    source = next(work.glob("bindloom-draft-*"))
    inventory = json.loads((source / "source-inventory.json").read_text())
    for entry in inventory:
        raw = (source / entry["path"]).read_bytes()
        assert len(raw) == entry["bytes"] and "sha256:" + hashlib.sha256(raw).hexdigest() == entry["digest"]
    native = work / "native"
    native.mkdir()
    with tarfile.open(args.distribution / receipt["nativeArchive"]["path"]) as archive:
        archive.extractall(native, filter="data")
    packaged_cli = next(native.glob("*/bin/bindloom"))
    assert "sha256:" + hashlib.sha256(packaged_cli.read_bytes()).hexdigest() == receipt["binaryDigest"]
    assert json.loads(run([packaged_cli, "engine"], work)) == receipt["engines"]
    installed = work / "installed"
    # Reuse only compiler object cache, never source or an existing installed CLI.
    env["CARGO_TARGET_DIR"] = str(ROOT / "target/package-test")
    run([tools / "cargo", "install", "--path", source / "crates/bindloom-cli", "--locked", "--offline", "--debug", "--root", installed], work)
    cli = installed / "bin/bindloom"
    assert json.loads(run([cli, "engine"], work)) == receipt["engines"]
    consumer = work / "consumer"
    consumer.mkdir()
    (consumer / "src").mkdir()
    (consumer / "Cargo.toml").write_text(f'''[package]\nname="bindloom-sdk-consumer"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nbindloom-contracts={{path={json.dumps(str(source / 'crates/bindloom-contracts'))}}}\nbindloom-core={{path={json.dumps(str(source / 'crates/bindloom-core'))}}}\n''')
    (consumer / "src/main.rs").write_text('''fn main() { let graph: bindloom_contracts::GraphDocument = bindloom_contracts::parse(&std::fs::read("graph.json").unwrap()).unwrap(); let pack = bindloom_contracts::parse(&std::fs::read("pack.json").unwrap()).unwrap(); let core = bindloom_contracts::parse(&std::fs::read("core.json").unwrap()).unwrap(); let checked = bindloom_core::CheckedGraph::check(graph, vec![pack, core]).unwrap(); println!("{}", checked.document().entities.len()); }''')
    for target, path in [("graph.json", "fixtures/routing/graph.json"), ("pack.json", "relation-packs/routing.json"), ("core.json", "relation-packs/core.json")]:
        shutil.copyfile(source / path, consumer / target)
    expected_entities = len(json.loads((consumer / "graph.json").read_text())["entities"])
    assert int(run([tools / "cargo", "run", "--offline", "--quiet"], consumer)) == expected_entities
    config = {"schemaVersion": "0.1.0", "documentType": "workspace-config", "id": "urn:workspace:installed", "namespace": "installed", "revision": "1",
              "sources": [{"id": "urn:source:installed", "adapter": "portable-shard", "path": "graph.json"}], "packs": ["pack.json"], "policy": "policy.json",
              "projections": [{"path": "projection.json", "emissions": [{"path": "bindings.rs", "language": "rust", "bindingSlot": "handler"}, {"path": "bindings.ts", "language": "typescript", "bindingSlot": "handler"}]}],
              "context": {}, "evaluatedAt": "2026-10-10T12:00:00Z"}
    graph = json.loads((consumer / "graph.json").read_text())
    handler = next(e for e in graph["entities"] if e["kind"] == "routing:handler")
    handler["locators"] = [{"uri": "rust:crate::service::greet"}, {"uri": "typescript:./handler.ts#greet"}]
    write(consumer / "graph.json", graph)
    policy = json.loads((source / "fixtures/routing/policy.json").read_text()); policy["graph"] = {"id": config["id"], "revision": "1"}
    write(consumer / "policy.json", policy); write(consumer / "config.json", config)
    shutil.copyfile(source / "fixtures/routing/projection-spec.json", consumer / "projection.json")
    no_node = {**env, "PATH": "/usr/bin:/bin"}
    assert shutil.which("node", path=no_node["PATH"]) is None
    generated = json.loads(run([cli, "generate", "config.json", "--root", consumer], consumer, env=no_node))
    baseline = generated["baseline"]; write(consumer / "baseline.json", baseline); original_baseline = (consumer / "baseline.json").read_bytes()
    for name, content in baseline["outputs"].items(): (consumer / name).write_text(content)
    (consumer / "service.rs").write_text('pub fn greet(input: &str) -> String { format!("Hello, {}!", input) }')
    (consumer / "main.rs").write_text('mod service; mod bindings; fn main() { let id = bindings::SemanticId::parse("urn:example:command:create-user").unwrap(); println!("{}", bindings::dispatch(id, "Ada")); }')
    run([tools / "rustc", "--edition=2024", "main.rs", "-o", "consumer"], consumer, env=no_node)
    assert run([consumer / "consumer"], consumer, env=no_node).strip() == "Hello, Ada!"
    (consumer / "handler.ts").write_text('export function greet(input: string): string { return `Hello, ${input}!`; }')
    (consumer / "package.json").write_text('{"type":"module"}')
    (consumer / "consumer.ts").write_text('import {dispatch} from "./bindings.js"; console.log(dispatch("urn:example:command:create-user", "Ada"));')
    run([args.node, args.tsc, "--strict", "--target", "ES2022", "--module", "NodeNext", "--moduleResolution", "NodeNext", "--outDir", "dist", "consumer.ts", "bindings.ts"], consumer)
    assert run([args.node, "dist/consumer.js"], consumer).strip() == "Hello, Ada!"
    write(consumer / "capture.json", baseline["captures"][0])
    shutil.copytree(source / "sdk/python/bindloom", installed / "python/bindloom")
    python_env = {**no_node, "PYTHONPATH": str(installed / "python")}
    python = shutil.which("python3")
    result = run([python, "-c", "from bindloom import Bindloom; import sys; print(Bindloom(sys.argv[1]).check(sys.argv[2], sys.argv[3], sys.argv[4])['status'])", cli, consumer / "config.json", consumer / "baseline.json", consumer], consumer, env=python_env)
    assert result.strip() == "unchanged"
    shutil.copytree(source / "sdk/typescript", consumer / "node_modules/bindloom-native-sdk-draft")
    (consumer / "sdk.ts").write_text('import {Bindloom} from "bindloom-native-sdk-draft"; const cli = new Bindloom(process.argv[2]!); console.log((cli.replay("capture.json") as {status:string}).status);')
    # Keep SDK test free of @types/node; declare only the fixture argv contract.
    (consumer / "argv.d.ts").write_text('declare const process: {argv: string[]};')
    run([args.node, args.tsc, "--strict", "--target", "ES2022", "--module", "NodeNext", "--moduleResolution", "NodeNext", "--outDir", "dist", "sdk.ts", "argv.d.ts"], consumer)
    assert json.loads(run([cli, "replay", "capture.json"], consumer))["status"] == "verified"
    assert run([args.node, "dist/sdk.js", cli], consumer).strip() == "verified"
    graph["entities"][0]["label"] = "changed installed source"; write(consumer / "graph.json", graph)
    drift = json.loads(run([cli, "check", "config.json", "baseline.json", "--root", consumer], consumer, expected=2))
    assert drift["status"] == "drift" and (consumer / "baseline.json").read_bytes() == original_baseline
    # Exercise the pinned discovery bridge through the installed native host.
    shutil.copyfile(source / "adapters/metamap-process.mjs", consumer / "bridge.mjs")
    (consumer / "src/input.ts").write_text('import {z} from "zod"; export const Name = z.string();')
    config["sources"] = [{"id": "urn:source:framework", "adapter": "process", "invocation": {"executable": str(args.node.resolve()), "arguments": [str(consumer / "bridge.mjs"), str(args.reference.resolve())], "codeInputs": ["bridge.mjs"], "bounds": {"maximumElapsedMs": 3000, "maximumStdoutBytes": 1048576, "maximumStderrBytes": 65536}}, "inputs": ["src/input.ts"], "config": {"adapter": "typescript-zod", "roots": ["src"]}}]
    # Empty selection remains an explicit valid discovery-only consumer here.
    policy["mappings"] = []; policy["constraints"] = []; write(consumer / "policy.json", policy)
    write(consumer / "projection.json", {"schemaVersion":"0.1.0","documentType":"projection-spec","id":"urn:projection:discovery","select":{"kinds":["zod-schema"]},"slots":[]})
    config["projections"][0]["emissions"] = []; write(consumer / "config.json", config)
    discovered = json.loads(run([cli, "generate", "config.json", "--root", consumer], consumer))
    assert len(discovered["baseline"]["captures"][0]["inputs"]["graph"]["entities"]) > 0
    assert discovered["baseline"]["discovery"][0]["adapter"] == "process"
    assert discovered["cacheHits"] == 0
    print("PASS: clean source-bundle installation, independent Rust SDK consumer, native Rust/TS execution, installed Python/TypeScript wrappers, read-only drift refusal, no-Node portable path, pinned framework process discovery.")
