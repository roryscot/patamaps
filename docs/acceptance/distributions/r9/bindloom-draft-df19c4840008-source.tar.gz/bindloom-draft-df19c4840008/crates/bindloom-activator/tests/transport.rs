use bindloom_activator::{ActivationRequest, ActivePointer, ProtectedHost};
use bindloom_contracts::{canonical_bytes, parse};
use serde_json::json;

#[test]
fn transport_never_accepts_host_options_or_ambiguous_json() {
    assert!(parse::<ActivationRequest>(br#"{"schemaVersion":"0.1.0","documentType":"activation-request","prepared":{},"approval":{},"now":"2026-01-01"}"#).is_err());
    assert!(
        parse::<ActivePointer>(br#"{"schemaVersion":"0.1.0","schemaVersion":"0.1.0"}"#).is_err()
    );
    let bytes=canonical_bytes(&json!({"schemaVersion":"0.1.0","documentType":"active-pointer","consumer":"urn:consumer:test","environment":"test","manifest":{"id":"urn:manifest:one","digest":"sha256:bad"},"trustPath":"/tmp/self-appointed"})).unwrap();
    assert!(parse::<ActivePointer>(&bytes).is_err());
}

#[test]
fn unsupported_host_refuses_without_touching_a_path() {
    if !cfg!(target_os = "linux") {
        let error = ProtectedHost::new("/does-not-exist/trust.json").unwrap_err();
        assert_eq!(error.code(), "ACTIVATION_UNSUPPORTED_HOST");
    }
}
