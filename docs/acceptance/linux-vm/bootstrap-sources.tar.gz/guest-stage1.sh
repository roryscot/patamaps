#!/bin/bash
set -euo pipefail
export HOME=/root RUSTUP_HOME=/usr/local/rustup CARGO_HOME=/usr/local/cargo
export PATH=/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export RUSTUP_TOOLCHAIN=1.99.0-aarch64-unknown-linux-gnu
unset SDKROOT
for component in /share/rust-components/*.tar.xz; do
 directory=$(basename "$component" .tar.xz)
 mkdir -p /rust-components
 tar -xJf "$component" -C /rust-components
 /bin/bash "/rust-components/$directory/install.sh" --prefix=/usr/local/rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu --disable-ldconfig
done
mkdir -p /root/.cargo /work /cached-registry /source
test -e /root/.cargo/bin || ln -s /usr/local/cargo/bin /root/.cargo/bin
tar -xzf /share/registry.tar.gz -C /cached-registry
mkdir -p /source-unpack
tar -xzf /share/source.tar.gz -C /source-unpack
cp -a /source-unpack/bindloom-draft-*/. /source/
printf 'BINDLOOM_LINUX_ENVIRONMENT\n'
uname -a
cat /etc/os-release
rustc -vV
cargo -V
python3 --version
stat -f -c 'filesystem=%T' /work
sh /source/scripts/test_linux.sh
printf 'BINDLOOM_LINUX_STAGE1_PASS\n'
