"""Project-local VM bootstrap; all writable storage is the private raw disk."""
import gzip
import argparse
import io
import json
import stat
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--resume", action="store_true")
parser.add_argument("--stage", choices=["stage1","stage2","stage3"], default="stage1")
args = parser.parse_args()


def member(name, data, mode, inode):
    name = name.encode() + b"\0"
    fields = [inode, mode, 0, 0, 1, 0, len(data), 0, 0, 0, 0, len(name), 0]
    header = b"070701" + b"".join(f"{x:08x}".encode() for x in fields)
    result = header + name
    result += b"\0" * (-len(result) % 4)
    result += data
    return result + b"\0" * (-len(data) % 4)


script = b'''#!/usr/bin/busybox sh
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
exec >/dev/console 2>&1
finish() {
 status=$?
 printf 'BINDLOOM_VM_GUEST_EXIT=%s\\n' "$status"
 busybox sync
 busybox poweroff -f
}
trap finish EXIT
set -eu
busybox mount -t proc proc /proc
busybox mount -t sysfs sys /sys
busybox mount -t devtmpfs dev /dev
modprobe virtio_blk
modprobe virtiofs
modprobe squashfs
busybox mkdir -p /modloop
busybox mount -t squashfs -o ro /dev/vdb /modloop
busybox mount --bind /modloop/modules /usr/lib/modules
modprobe ext4
busybox mkdir -p /share /newroot
busybox mount -t virtiofs -o ro bindloom-share /share
printf 'BINDLOOM_PRIVATE_DISK_FORMAT\\n'
mke2fs -F -t ext4 -L bindloom-test /dev/vda
busybox mount -t ext4 /dev/vda /newroot
while IFS= read -r layer; do
 printf 'BINDLOOM_ROOT_LAYER=%s\\n' "$layer"
 busybox tar -xzf "/share/$layer" -C /newroot
done </share/layers.txt
busybox mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/share
busybox mount --bind /proc /newroot/proc
busybox mount --bind /sys /newroot/sys
busybox mount --bind /dev /newroot/dev
busybox mount --bind /share /newroot/share
busybox cp /share/guest-stage1.sh /newroot/guest-stage1.sh
busybox chroot /newroot /bin/bash /guest-stage1.sh
'''
members = {}
for receipt in json.loads((ROOT / "apk/receipts.json").read_text()):
    archive = ROOT / "apk" / Path(receipt["url"]).name
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive.read_bytes())), mode="r:", ignore_zeros=True) as tar:
        for item in tar:
            name = item.name.removeprefix("./").rstrip("/")
            if name.startswith("."):
                continue
            assert name and not name.startswith("/") and ".." not in name.split("/")
            if item.isfile():
                members[name] = (tar.extractfile(item).read(), stat.S_IFREG | item.mode)
            elif item.issym():
                members[name] = (item.linkname.encode(), stat.S_IFLNK | item.mode)
            elif item.isdir():
                members[name] = (b"", stat.S_IFDIR | item.mode)
            else:
                raise ValueError(item)
members["init"] = (script, stat.S_IFREG | 0o755)
if args.resume:
    start=script.index(b"printf 'BINDLOOM_PRIVATE_DISK_FORMAT")
    end=script.index(b"busybox mkdir -p /newroot/proc", start)
    script=script[:start]+b"busybox mount -t ext4 /dev/vda /newroot\n"+script[end:]
    members["init"] = (script, stat.S_IFREG | 0o755)
if args.stage != "stage1":
    script=script.replace(b"guest-stage1.sh",f"guest-{args.stage}.sh".encode())
    members["init"] = (script, stat.S_IFREG | 0o755)
cpio = b"".join(member(name, raw, mode, inode) for inode, (name, (raw, mode)) in enumerate(sorted(members.items()), 91000))
cpio += member("TRAILER!!!", b"", 0, 99999)
(ROOT / "initramfs-stage1").write_bytes((ROOT / "initramfs-virt").read_bytes() + gzip.compress(cpio, mtime=0))
(ROOT / "stage1-init.sh").write_bytes(script)
(ROOT / f"share/guest-{args.stage}.sh").write_bytes((ROOT / f"guest-{args.stage}.sh").read_bytes())
disk = ROOT / "disk.raw"
if not disk.exists():
    with disk.open("xb") as output:
        output.truncate(32 * 1024 * 1024 * 1024)
print("Prepared a network-free guest with project-owned sparse raw disk and read-only staged inputs.")
