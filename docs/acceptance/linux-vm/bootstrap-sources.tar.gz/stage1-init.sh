#!/usr/bin/busybox sh
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
exec >/dev/console 2>&1
finish() {
 status=$?
 printf 'BINDLOOM_VM_GUEST_EXIT=%s\n' "$status"
 busybox sync
 busybox poweroff -f
}
trap finish EXIT
set -eu
busybox mount -t proc proc /proc
busybox mount -t sysfs sys /sys
busybox mount -t devtmpfs dev /dev
modprobe virtio_blk
modprobe virtiofs
modprobe squashfs
busybox mkdir -p /modloop
busybox mount -t squashfs -o ro /dev/vdb /modloop
busybox mount --bind /modloop/modules /usr/lib/modules
modprobe ext4
busybox mkdir -p /share /newroot
busybox mount -t virtiofs -o ro bindloom-share /share
busybox mount -t ext4 /dev/vda /newroot
busybox mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/share
busybox mount --bind /proc /newroot/proc
busybox mount --bind /sys /newroot/sys
busybox mount --bind /dev /newroot/dev
busybox mount --bind /share /newroot/share
busybox cp /share/guest-stage3.sh /newroot/guest-stage3.sh
busybox chroot /newroot /bin/bash /guest-stage3.sh
