#!/bin/bash
set -euo pipefail
export HOME=/root RUSTUP_HOME=/usr/local/rustup CARGO_HOME=/usr/local/cargo
export RUSTUP_TOOLCHAIN=1.99.0-aarch64-unknown-linux-gnu
export PATH=/opt/bindloom-python/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TERM_COLOR=never
unset SDKROOT
mkdir -p /output
mount -t virtiofs bindloom-results /output
trap 'status=$?; cp -R /results/linux-candidate-with-host /output/; test ! -f /results/linux-installation.json || cp /results/linux-installation.json /output/; exit "$status"' EXIT
tar -xzf /share/reference-assets.tar.gz -C /reference
cd /source
python3 scripts/test_distribution.py /results/linux-candidate-with-host --node /usr/local/node/bin/node --tsc /reference/node_modules/typescript/lib/tsc.js --reference /reference --output /results/linux-installation.json
printf 'BINDLOOM_LINUX_STAGE3_PASS\n'
