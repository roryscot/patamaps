#!/bin/bash
set -euo pipefail
export HOME=/root RUSTUP_HOME=/usr/local/rustup CARGO_HOME=/usr/local/cargo
export RUSTUP_TOOLCHAIN=1.99.0-aarch64-unknown-linux-gnu
export PATH=/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TERM_COLOR=never
unset SDKROOT
if ! test -x /opt/bindloom-python/bin/python3.12; then
 mkdir -p /python-build
 tar -xJf /share/Python-3.12.11.tar.xz -C /python-build
 cd /python-build/Python-3.12.11
 ./configure --prefix=/opt/bindloom-python --without-ensurepip
 make -j4
 make install
fi
export PATH=/opt/bindloom-python/bin:$PATH
printf 'BINDLOOM_LINUX_STAGE2_ENVIRONMENT\n'
uname -a
grep /dev/vda /proc/mounts
rustc -vV
python3 - <<'PY'
import inspect,tarfile,sys
print(sys.version)
print('safe extraction filter available:', 'filter' in inspect.signature(tarfile.TarFile.extractall).parameters)
assert 'filter' in inspect.signature(tarfile.TarFile.extractall).parameters
PY
mkdir -p /reference /usr/local/node /results
tar -xzf /share/reference-runtime.tar.gz -C /reference
tar -xJf /share/node-v22.16.0-linux-arm64.tar.xz --strip-components=1 -C /usr/local/node
/usr/local/node/bin/node --version
cd /source
cp /share/package-current.py scripts/package.py
cp /share/test-distribution-current.py scripts/test_distribution.py
cargo fmt --all -- --check
cargo build --release --workspace --locked --offline
target/release/bindloom engine
BINDLOOM_TEST_COMPILER_BINARY=/source/target/release/bindloom BINDLOOM_TEST_ACTIVATOR_BINARY=/source/target/release/bindloom-activator cargo test -p bindloom-activator --lib --locked --offline -- --test-threads=1
python3 scripts/package.py --binary target/release/bindloom --activator-binary target/release/bindloom-activator --build-profile release --output /results/linux-candidate-with-host
python3 scripts/test_distribution.py /results/linux-candidate-with-host --node /usr/local/node/bin/node --tsc /reference/node_modules/typescript/lib/tsc.js --reference /reference --output /results/linux-installation.json
printf 'BINDLOOM_LINUX_STAGE2_PASS\n'
