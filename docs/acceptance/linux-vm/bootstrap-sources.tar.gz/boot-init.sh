#!/usr/bin/busybox sh
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
exec >/dev/console 2>&1
busybox mount -t proc proc /proc
busybox mount -t sysfs sys /sys
busybox mount -t devtmpfs dev /dev
printf 'BINDLOOM_VM_BOOT_START\n'
busybox uname -a
busybox --list | busybox grep -E '(mkfs|mke2fs|chroot|switch_root)'
printf 'BINDLOOM_VM_BOOT_PASS\n'
busybox poweroff -f
