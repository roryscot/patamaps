//! Pure authorization under explicitly supplied current context. This crate
//! cannot establish host provenance, read a clock, sign, or activate a consumer.
#![forbid(unsafe_code)]
mod approval;
mod artifacts;
mod delta;
mod model;
mod proposal;
mod trust;
mod util;
pub use approval::{
    AuthorizationRecord, AuthorizedChange, approval_signing_bytes, attach_signature,
    check_signed_approval, create_approval_payload, verify_approval,
};
pub use delta::change_requirements;
pub use model::*;
pub use proposal::{
    CheckedProposal, check_prepared, check_proposal, create_proposal, governance_executor_id,
    verify_artifact_bytes,
};
pub use trust::{check_trusted_consumer, verify_ed25519_signature};
pub use util::document_digest;
