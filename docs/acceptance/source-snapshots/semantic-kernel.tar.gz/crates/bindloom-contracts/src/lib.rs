//! Draft wire records carry no checked, admitted, or authorized status.
#![forbid(unsafe_code)]

mod integer;
mod json;
mod model;
mod semantic;

pub use integer::{MAX_SAFE_INTEGER, SafeInteger};
pub use json::{ContractError, byte_digest, canonical_bytes, canonical_digest, parse, parse_value};
pub use model::*;
pub use semantic::*;

pub const MAX_INPUT_BYTES: usize = 16 * 1024 * 1024;
pub const MAX_JSON_DEPTH: usize = 64;
pub const MAX_JSON_VALUES: usize = 2_000_000;
pub const PROFILE: &str = "bindloom-routing-draft-1";
pub const SEMANTIC_PROFILE: &str = "bindloom-semantic-draft-1";

/// Optional object fields may be absent, but explicit null is not absence.
pub fn present<'de, D, T>(deserializer: D) -> Result<Option<T>, D::Error>
where
    D: serde::Deserializer<'de>,
    T: serde::Deserialize<'de>,
{
    T::deserialize(deserializer).map(Some)
}

/// A nullable field must still be present when its meaning is an explicit
/// choice. Serde's ordinary Option otherwise silently treats absence as null.
pub fn nullable<'de, D, T>(deserializer: D) -> Result<Option<T>, D::Error>
where
    D: serde::Deserializer<'de>,
    T: serde::Deserialize<'de>,
{
    <Option<T> as serde::Deserialize>::deserialize(deserializer)
}
