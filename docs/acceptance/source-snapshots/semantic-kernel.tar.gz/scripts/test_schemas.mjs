// Optional developer tool: schemas are loaded explicitly and entirely locally.
import {readFileSync,readdirSync} from "node:fs";
import {createRequire} from "node:module";
import {resolve} from "node:path";
import {spawnSync} from "node:child_process";
const require=createRequire(resolve(process.argv[2],"package.json"));
const Ajv=require("ajv/dist/2020.js").default,formats=require("ajv-formats");
const ajv=formats(new Ajv({strict:true,allErrors:true}));
for(const file of readdirSync("schemas"))ajv.addSchema(JSON.parse(readFileSync("schemas/"+file,"utf8")));
for(const file of readdirSync("schemas"))ajv.getSchema(JSON.parse(readFileSync("schemas/"+file,"utf8")).$id);
const names={"graph.json":"graph","pack.json":"relation-pack","request.json":"composition-request","policy.json":"policy","projection-spec.json":"projection-spec"};
for(const file of readdirSync("fixtures/laws")){
 const validator=ajv.getSchema("urn:bindloom:draft:1:schema:"+names[file]);
 if(!validator(JSON.parse(readFileSync("fixtures/laws/"+file,"utf8"))))throw Error(file+JSON.stringify(validator.errors));
}
const proposed=spawnSync(resolve(process.argv[3]),["derive","fixtures/laws/graph.json","fixtures/laws/request.json","--relation-pack","fixtures/laws/pack.json"],{encoding:"utf8"});
if(proposed.status!==0)throw Error(proposed.stdout+proposed.stderr);
const proof=JSON.parse(proposed.stdout).derivation,validator=ajv.getSchema("urn:bindloom:draft:1:schema:derivation");
if(!validator(proof))throw Error(JSON.stringify(validator.errors));
console.log("PASS: all successor schemas compile in the local registry; five law fixtures and an actual Rust derivation validate.");
